# Project New
## 1 Agregar postBuffer en git config
[http]
        postBuffer = 524288000
## 2 editar package.json
## 3 editar README.md
## 4 editar NombreDeProyecto en /css
## 5 editar NombreDeProyecto en /src
## 6 editar robots.txt
## 7 editar humans.txt