# Project New
## 1 editar package.json
## 2 editar README.md
## 3 editar NombreDeProyecto en /css
## 4 editar NombreDeProyecto en /src
## 5 editar robots.txt
## 6 editar humans.txt