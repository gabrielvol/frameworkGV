***
# NombreDelProyecto
###### Agencia  
***

#### Datos FTP
`http://wwwsitioweb/`  
`00000000000`

Usuario
`user`

Contraseña
`pass`  
***


#### Panel de control
`httpwwwsitiowebcpanel`

Usuario 
`user`

Contraseña
`pass`  
***


#### Datos FTP Alternativos
`http://wwwsitioweb/`  

Usuario
`user`

Contraseña
`pass`  
***


#### DNS y Contacto
AgenciaDeHosting

DNS 1
`dnshosting (000000000000)`

DNS 2
`dnshosting (000000000000)`

DNS 3
`dnshosting (000000000000)`

DNS 4
`dnshosting (000000000000)`

Contacto técnico
`Nombre` 

Teléfono
`12345678`

Correo
`infocorreocom`  
***


#### Google Account
Usuario
`usergmailcom`

Contraseña
`pass`  
***


#### WordPress access
`http://sitioweb/wp-admin`

Usuario
`user`

Contraseña
`pass`  
***


#### Licencia
CC BY-NC-ND 4.0  
Reconocimiento-NoComercial-SinObraDerivada 4.0 Internacional  

URLS:  
Inglés  
`https://creativecommons.org/licenses/by-nc-nd/4.0/`  
`https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode` 
 
Español  
`https://creativecommons.org/licenses/by-nc-nd/4.0/deed.es`  
***