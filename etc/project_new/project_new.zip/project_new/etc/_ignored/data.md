<?php
/* * Coordenada32 * ============================================================
   Casilla de Correo contacto@
   ========================================================================== */
?>

*Nombre de usuario*
contacto@coordenada32.com.ar

*Contraseña*
coordenada3280

*Servidor entrante*
mail.coordenada32.com.ar

*IMAP Port*
993

*POP3 Port*
995 

*Servidor de correo*
mail.coordenada32.com.ar

*SMTP Port*
465 

IMAP, POP3 y SMTP require authentication.