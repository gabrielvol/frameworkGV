***
# NombreDelProyecto
###### Agencia  
***

#### Panel de control WHM
`http://wwwsitioweb/`

Usuario
`user`

Pass
`pass`  
***


#### Datos de cPanel
`http://wwwsitioweb/`

Usuario
`user`

Pass
`pass`  
***


#### Datos FTP
`http://wwwsitioweb/`  
`00000000000`

Usuario
`user`

Pass
`pass`  
***


#### Datos FTP
`http://wwwsitioweb/`  

Usuario
`user`

Pass
`pass`  
***


#### DNS y Contacto
AgenciaDeHosting

DNS 1
`dnshosting (000000000000)`

DNS 2
`dnshosting (000000000000)`

DNS 3
`dnshosting (000000000000)`

DNS 4
`dnshosting (000000000000)`

Contacto tecnico
`Nombre` 

Telefono
`12345678`

Correo
`infocorreocom`  
***


#### Google Account
Usuario
`usergmailcom`

Pass
`pass`  
***


#### WordPress access
`http://sitioweb/wp-admin`

Usuario
`user`

Pass
`pass`  
***


#### Licencia
CC BY-NC-ND 4.0  
Reconocimiento-NoComercial-SinObraDerivada 4.0 Internacional  

URLS:  
Ingles  
`https://creativecommons.org/licenses/by-nc-nd/4.0/`  
`https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode` 
 
Espanol  
`https://creativecommons.org/licenses/by-nc-nd/4.0/deed.es`  
***