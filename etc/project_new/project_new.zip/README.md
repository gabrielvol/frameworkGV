# NombreDelProyecto
#### Agencia  

#### Licencia
CC BY-NC-ND 4.0  
Reconocimiento-NoComercial-SinObraDerivada 4.0 Internacional  

Español  
https://creativecommons.org/licenses/by-nc-nd/4.0/deed.es  

Inglés  
https://creativecommons.org/licenses/by-nc-nd/4.0/  
https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode  